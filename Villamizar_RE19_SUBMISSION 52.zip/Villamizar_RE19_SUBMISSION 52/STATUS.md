# Artifact Badge

We are applying for the Available badge for following reasons:

We have documented our artifacts in a consistent and complete manner. These artifacts were verified by three independent researches in order to assure the suitability of the artifacts.

Furthermore, the artifacts are avaliable on Zenodo. We have minted a DOI to give this artifact a permanent unique identifier [![DOI](https://zenodo.org/badge/DOI/10.5281/zenodo.3260328.svg)](https://doi.org/10.5281/zenodo.3260328).