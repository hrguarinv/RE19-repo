# MIT License

Copyright (c) 2019

Permission is hereby granted, free of charge, to any person obtaining a copy of this associated documentation files, to deal in the files without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the files is furnished to do so.